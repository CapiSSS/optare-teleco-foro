Welcome tho this technical challenge!

Here is your assignment:

This project lists every character of all Star Wars movies, using the following REST API https://swapi.co/ 

Your tasks are:
 * Modify this project to add for each character the list of vehicles and their other pilots (character --> vehicle[] --> pilot[]:
   * for each character: add the list of vehicles. If there is more than one vehicle print them separated by a comma
   * for each vehicle: add the list of pilots excluding the current character. If there is more than one pilot print them separated by a comma.
   * print the list of vehicles in alphabetical ordere.
   For example:

```
2018-04-09 10:04:52 [swapi.Main.main()] INFO  swapi.Main - Luke Skywalker - Vehicles: [Imperial Speeder Bike [Wedge Antilles], Snowspeeder [Leia Organa]]
```

 * Modify the project to print the list of characters in revers order by name


You can test project with following command:

```
$ .\mvnw clean package exec:java
``` 

Important points that will be evaluated for your final score:
 * Functionality achieved:
   * List of vehicles
   * List of vehicle pilots
   * List of vehicle pilots is ordered
   * List of characters sorted in reverse order by name
 * Time to complete and send the solution
 * Structure and quality of the code

Good luck and take it easy!